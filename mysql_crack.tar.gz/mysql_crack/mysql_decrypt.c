#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/types.h>
#include "sha1.h"

#define MAXLEN 1000

uint8_t hash[20];

int MysqlDecrypt(char *test){
	SHA1Context sha,shaa;
	int i;

	uint8_t Message_Digest[20];
	uint8_t Message_Digestx[20];

	SHA1Reset(&sha);
	SHA1Reset(&shaa);

	SHA1Input(&sha,(const unsigned char *)test,strlen(test));

	SHA1Result(&sha, Message_Digest);

	SHA1Input(&shaa,Message_Digest,20);

	SHA1Result(&shaa, Message_Digestx);

	for(i = 0; i < 20 ; ++i){
		if(Message_Digestx[i] != hash[i])
			return 1;
	}

	return 0;
}

int hex_to_dec(char a,char b){
	int i,j,k;
	if(a >= 65 && a <= 70){

		for(i=65;i<71;i++){
			if(a == i){
				j = a-55;
				break;
			}
		}

	} else {
		j = a-48;
	}

        if(b >= 65 && b <= 70){

        	for(i=65;i<71;i++){
                	if(b == i){
                        k = b-55;
                        break;
                	}
        	}

        } else {
                k = b-48;
        }

	return (j*16+k);
}

char strup(char a){
	if(a >= 97 && a <= 102)
		return a-32;
	return a;
}

int GenHash(uint8_t hash[20],char *h){
	if(strlen(h)!= 40)
		return 1;

	int i,j=0;
	for(i=0;i<40;i+=2){
		hash[j] = hex_to_dec(strup(h[i]),strup(h[i+1]));
		j++;
	}
	return 0;
}

int help(void){
	char banner[]=
	"\n [+] Mysql Hash Cracker By MMxM\n" \
	" (hc0der.blogspot.com)\n\n" \
	" Usage:\n\n" \
	"\tmysql_crack <hash> <wordlist> <priority_level>\n\n";
	printf("%s",banner);
	exit(0);
}

int main(int argc,char **argv){
	if(argc < 3 || argc > 4)
		help();

	printf("\n[+] PID:%lld\n",(long long int)getpid());
	int X = 0;
	FILE *Words;

	if(GenHash(hash,argv[1]) == 1){
		fprintf(stderr,"\n[-] Invalid mysql Hash\n\n");
		return 1;
	}

	Words = fopen(argv[2],"rb");
	if(Words == NULL){
		fprintf(stderr,"\n[-] Failed to open file %s\n\n",argv[2]);
		return 1;
	}
	if(argc > 3)
		X = atoi(argv[3]);


	if(getuid() == 0 && X != 0 && X >= -20 && X <= 20){
		printf("[+] Changing Process Priority to (%d) ... ",X);
		if(setpriority(PRIO_PROCESS, 0, X) == 0)
			printf("[OK]\n");
		else
			printf("[FAIL]\n");
	}

	printf("\nDecrypting...\n");

	char Line[MAXLEN];
	char C;
	int Pos = 0;

	while((C=fgetc(Words)) != EOF){
		if(C == '\n'){
			Line[Pos] = '\0';
			Pos = 0;
			if(MysqlDecrypt(Line) == 0){
				printf("\n\n\t[+] Hash Cracked: '%s'\n\n",Line);
				break;
			}
		} else {
			Line[Pos] = C;
			Pos++;
		}
	}

	fclose(Words);
	printf("\n[Finish]\n\n");
	return(0);

}
